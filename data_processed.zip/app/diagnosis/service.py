"""Core differential-diagnosis service."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd

from app.config import settings
from app.diagnosis.explainer import build_tree_explainer, explain_prediction
from src.covid_model import load_covid_model, load_covid_metadata
from src.dengue_model import load_dengue_model, load_dengue_metadata
from src.malaria_model import load_malaria_model, load_malaria_metadata


DISEASES = ["malaria", "covid", "dengue"]


class DifferentialDiagnosis:
    """Load model artifacts once and expose structured diagnosis operations."""

    def __init__(self, paths=settings):
        self.paths = paths

        # Malaria
        self.malaria_model, self.malaria_scaler, self.malaria_features = load_malaria_model(paths.models_dir)
        self.malaria_medians = self._load_optional(paths.malaria_medians, {})
        self.malaria_encoders = self._load_optional(paths.malaria_label_encoders, {})
        self.malaria_metadata = self._load_optional(paths.malaria_metadata, {})

        # COVID
        self.covid_model, self.covid_scaler, self.covid_features = load_covid_model(paths.models_dir)
        self.covid_medians = self._load_optional(paths.covid_medians, {})
        self.covid_encoders = self._load_optional(paths.covid_label_encoders, {})
        self.covid_metadata = self._load_optional(paths.covid_metadata, {})

        # Dengue
        self.dengue_model, self.dengue_scaler, self.dengue_features = load_dengue_model(paths.models_dir)
        self.dengue_medians = self._load_optional(paths.dengue_medians, {})
        self.dengue_encoders = self._load_optional(paths.dengue_label_encoders, {})
        self.dengue_metadata = self._load_optional(paths.dengue_metadata, {})

        # SHAP explainers
        self.malaria_explainer = build_tree_explainer(self.malaria_model) if self.malaria_model else None
        self.covid_explainer = build_tree_explainer(self.covid_model) if self.covid_model else None
        self.dengue_explainer = build_tree_explainer(self.dengue_model) if self.dengue_model else None

    # ------------------------------------------------------------------
    # Artifact loading
    # ------------------------------------------------------------------

    @staticmethod
    def _load_optional(path: Path, default: Any) -> Any:
        try:
            return joblib.load(path)
        except (FileNotFoundError, OSError):
            return default

    # ------------------------------------------------------------------
    # Input preparation
    # ------------------------------------------------------------------

    @staticmethod
    def _encode_categoricals(values: dict[str, Any], encoders: dict[str, Any]) -> dict[str, Any]:
        values = dict(values)
        for column, encoder in encoders.items():
            value = values.get(column)
            if isinstance(value, str):
                try:
                    values[column] = int(encoder.transform([value])[0])
                except (ValueError, KeyError):
                    values[column] = -1
        return values

    def _prepare_input(
        self,
        patient_data: dict[str, Any],
        features: list[str],
        medians: dict[str, Any],
        encoders: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Build a dict with one entry per required feature.

        Missing features are filled with sentinel values so the model
        sees a consistent "unknown" signal. Numeric features missing from
        patient_data fall back to the training median, then to the
        numeric sentinel.
        """
        prepared: dict[str, Any] = {}
        for feature in features:
            if feature in patient_data and patient_data[feature] is not None:
                prepared[feature] = patient_data[feature]
            else:
                # Numeric feature: use median if available, else sentinel
                if feature in medians:
                    prepared[feature] = medians[feature]
                else:
                    # Could be a binary or categorical feature
                    prepared[feature] = settings.binary_missing

        if encoders:
            prepared = self._encode_categoricals(prepared, encoders)

        return prepared

    @staticmethod
    def _predict_probability(model: Any, scaler: Any, features: list[str], prepared: dict[str, Any]) -> tuple[int, float]:
        df = pd.DataFrame([prepared], columns=features)
        scaled = scaler.transform(df)
        prediction = int(model.predict(scaled)[0])
        probabilities = model.predict_proba(scaled)[0]
        return prediction, float(probabilities[1])

    # ------------------------------------------------------------------
    # Feature availability
    # ------------------------------------------------------------------

    @staticmethod
    def _feature_availability(patient_data: dict[str, Any], features: list[str]) -> tuple[int, int, float]:
        provided = sum(
            1 for f in features
            if f in patient_data and patient_data[f] is not None
        )
        total = len(features)
        availability = provided / total if total > 0 else 0.0
        return provided, total, availability

    # ------------------------------------------------------------------
    # Bayesian prevalence correction
    # ------------------------------------------------------------------

    @staticmethod
    def _prevalence_correct(prob: float, training_prev: float, deployment_prev: float) -> float:
        """Convert a calibrated probability from one prevalence regime to another.

        Uses the odds-ratio transformation:
            odds_deployment = odds_training * (prior_deployment / prior_training)
            P_deployment = odds_deployment / (1 + odds_deployment)
        """
        if prob <= 0.0 or prob >= 1.0:
            return prob
        if training_prev <= 0.0 or training_prev >= 1.0:
            return prob
        odds_training = prob / (1.0 - prob)
        odds_deployment = odds_training * (deployment_prev / training_prev)
        return odds_deployment / (1.0 + odds_deployment)

    def _get_training_prevalence(self, disease: str) -> float:
        meta = getattr(self, f"{disease}_metadata", {}) or {}
        return float(meta.get("test_metrics", {}).get("positive_rate", 0.5))

    # ------------------------------------------------------------------
    # Confidence
    # ------------------------------------------------------------------

    @staticmethod
    def _confidence_level(prob: float, availability: float) -> str:
        if prob >= settings.confidence_high_prob and availability >= settings.confidence_high_coverage:
            return "High"
        if prob >= settings.confidence_medium_prob and availability >= settings.confidence_medium_coverage:
            return "Medium"
        return "Low"

    # ------------------------------------------------------------------
    # Main diagnosis
    # ------------------------------------------------------------------

    def diagnose(self, patient_data: dict[str, Any], session_id: str | None = None) -> dict[str, Any]:
        if any(m is None for m in (self.malaria_model, self.covid_model, self.dengue_model)):
            raise RuntimeError("All three disease models must be available.")

        patient_data = dict(patient_data)

        per_disease: dict[str, dict[str, Any]] = {}

        for disease in DISEASES:
            model = getattr(self, f"{disease}_model")
            scaler = getattr(self, f"{disease}_scaler")
            features = getattr(self, f"{disease}_features")
            medians = getattr(self, f"{disease}_medians")
            encoders = getattr(self, f"{disease}_encoders")
            explainer = getattr(self, f"{disease}_explainer")

            prepared = self._prepare_input(patient_data, features, medians, encoders)
            pred, prob = self._predict_probability(model, scaler, features, prepared)

            provided, total, availability = self._feature_availability(patient_data, features)

            training_prev = self._get_training_prevalence(disease)
            deployment_prev = settings.deployment_prevalence[disease]

            if availability >= 0.6:
                corrected_prob = prob
            else:
                corrected_prob = self._prevalence_correct(prob, training_prev, deployment_prev)

            # Feature-availability weighting
            if availability >= 0.6:
                weight = 1.0
            else:
                weight = availability / 0.6
            weighted_prob = corrected_prob * weight

            explanation = {}
            if explainer is not None:
                try:
                    explanation = explain_prediction(explainer, scaler, features, prepared)
                except Exception:
                    explanation = {"base_rate_probability": 0.0, "raw_model_probability": prob, "top_factors": []}

            per_disease[disease] = {
                "disease": disease,
                "probability": prob,
                "adjusted_probability": weighted_prob,
                "model_prediction": "Positive" if pred == 1 else "Negative",
                "features_provided": provided,
                "features_total": total,
                "feature_availability": availability,
                "training_prevalence": training_prev,
                "deployment_prevalence": deployment_prev,
                "explanation": explanation,
            }

        # Renormalize adjusted probabilities
        total_weighted = sum(d["adjusted_probability"] for d in per_disease.values())
        if total_weighted > 0:
            for disease in DISEASES:
                per_disease[disease]["adjusted_probability"] /= total_weighted

        # Confidence per disease
        for disease in DISEASES:
            per_disease[disease]["confidence"] = self._confidence_level(
                per_disease[disease]["adjusted_probability"],
                per_disease[disease]["feature_availability"],
            )

        # Arbitration
        sorted_diseases = sorted(
            DISEASES,
            key=lambda d: per_disease[d]["adjusted_probability"],
            reverse=True,
        )
        winner = sorted_diseases[0]
        winner_prob = per_disease[winner]["adjusted_probability"]

        ambiguity_note = None
        if len(sorted_diseases) >= 2:
            runner_up = sorted_diseases[1]
            gap = winner_prob - per_disease[runner_up]["adjusted_probability"]
            if gap < settings.ambiguity_gap:
                ambiguity_note = (
                    f"Ambiguous between {winner.title()} "
                    f"({winner_prob:.2f}) and {runner_up.title()} "
                    f"({per_disease[runner_up]['adjusted_probability']:.2f})"
                )

        if winner_prob < settings.rejection_threshold:
            primary = "Unclear"
            full = "Unable to confidently diagnose — insufficient features or low probability"
        else:
            primary = winner.title()
            full = primary

        recommendations = self._recommendations(primary)

        result = {
            "primary_diagnosis": primary,
            "full_diagnosis": full,
            "confidence": per_disease[winner]["confidence"] if winner_prob >= settings.rejection_threshold else "Low",
            "predictions": per_disease,
            "recommendations": recommendations,
            "ambiguity_note": ambiguity_note,
            "extracted_features": patient_data,

            # Backward-compatible fields
            "malaria_probability": per_disease["malaria"]["probability"],
            "covid_probability": per_disease["covid"]["probability"],
            "dengue_probability": per_disease["dengue"]["probability"],
            "malaria_model_prediction": per_disease["malaria"]["model_prediction"],
            "covid_model_prediction": per_disease["covid"]["model_prediction"],
            "dengue_model_prediction": per_disease["dengue"]["model_prediction"],
            "malaria_explanation": per_disease["malaria"]["explanation"],
            "covid_explanation": per_disease["covid"]["explanation"],
            "dengue_explanation": per_disease["dengue"]["explanation"],
            "covid_model_status": "provisional — weak symptom-based signal (F1 ~ 0.74)",
        }

        return result

    # ------------------------------------------------------------------
    # Recommendations
    # ------------------------------------------------------------------

    @staticmethod
    def _recommendations(primary: str) -> list[str]:
        if primary == "Malaria":
            return [
                "🔬 Order: Blood smear microscopy or Rapid Diagnostic Test (RDT)",
                "💊 Consider: Artemisinin-based combination therapy (ACT)",
                "📊 Monitor: Platelet count, hemoglobin, blood glucose",
            ]
        if primary == "Covid":
            return [
                "🔬 Order: RT-PCR or Rapid Antigen Test for COVID-19",
                "💊 Consider: Supportive care; oxygen therapy if SpO₂ < 94%",
                "📊 Monitor: Oxygen saturation, respiratory rate",
                "⚠️ Note: Symptom-based COVID prediction is unreliable; confirm with test",
            ]
        if primary == "Dengue":
            return [
                "🔬 Order: Dengue NS1 antigen + IgM/IgG serology",
                "💊 Consider: Supportive care; avoid NSAIDs (bleeding risk)",
                "📊 Monitor: Platelet count, hematocrit, signs of plasma leakage",
            ]
        return [
            "🔬 Order: Malaria RDT, COVID RT-PCR, and Dengue NS1",
            "🔄 Re-evaluate: If symptoms persist or worsen",
            "⚠️ Insufficient information for confident diagnosis — please provide more clinical detail",
        ]


def print_diagnosis_report(result: dict[str, Any]) -> None:
    print("\n" + "=" * 60)
    print(f"DIAGNOSIS: {result['full_diagnosis']}")
    print(f"Confidence: {result['confidence']}")
    print("=" * 60)
    for disease in DISEASES:
        pred = result["predictions"][disease]
        print(
            f"\n{disease.title()}:\n"
            f"  Raw P:        {pred['probability']:.3f}\n"
            f"  Adjusted P:   {pred['adjusted_probability']:.3f}\n"
            f"  Confidence:   {pred['confidence']}\n"
            f"  Features:     {pred['features_provided']}/{pred['features_total']}"
        )
    if result.get("ambiguity_note"):
        print(f"\n⚠️  {result['ambiguity_note']}")
    print("\nRecommendations:")
    for rec in result["recommendations"]:
        print(f"  {rec}")