"""Application configuration and project paths."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / ".env")


@dataclass(frozen=True)
class Settings:
    project_root: Path = PROJECT_ROOT
    data_dir: Path = PROJECT_ROOT / "data"
    data_processed_dir: Path = PROJECT_ROOT / "data_processed"
    models_dir: Path = PROJECT_ROOT / "models"
    logs_dir: Path = PROJECT_ROOT / "logs"
    reports_dir: Path = PROJECT_ROOT / "reports"

    # Raw datasets
    malaria_data: Path = PROJECT_ROOT / "data" / "Malaria_Dataset.csv"
    covid_data: Path = PROJECT_ROOT / "data" / "covid19_balanced_sample_2000.xlsx"
    dengue_data: Path = PROJECT_ROOT / "data" / "Dengue_clinical_dataset.csv"

    # Processed datasets
    malaria_clean: Path = PROJECT_ROOT / "data_processed" / "malaria_clean.csv"
    covid_clean: Path = PROJECT_ROOT / "data_processed" / "covid_clean.csv"
    dengue_clean: Path = PROJECT_ROOT / "data_processed" / "dengue_clean.csv"

    # Malaria model artifacts
    malaria_model: Path = PROJECT_ROOT / "models" / "malaria" / "model.pkl"
    malaria_scaler: Path = PROJECT_ROOT / "models" / "malaria" / "scaler.pkl"
    malaria_features: Path = PROJECT_ROOT / "models" / "malaria" / "features.pkl"
    malaria_medians: Path = PROJECT_ROOT / "models" / "malaria" / "medians.pkl"
    malaria_label_encoders: Path = PROJECT_ROOT / "models" / "malaria" / "label_encoders.pkl"
    malaria_metadata: Path = PROJECT_ROOT / "models" / "malaria" / "metadata.pkl"

    # COVID model artifacts
    covid_model: Path = PROJECT_ROOT / "models" / "covid" / "model.pkl"
    covid_scaler: Path = PROJECT_ROOT / "models" / "covid" / "scaler.pkl"
    covid_features: Path = PROJECT_ROOT / "models" / "covid" / "features.pkl"
    covid_medians: Path = PROJECT_ROOT / "models" / "covid" / "medians.pkl"
    covid_label_encoders: Path = PROJECT_ROOT / "models" / "covid" / "label_encoders.pkl"
    covid_metadata: Path = PROJECT_ROOT / "models" / "covid" / "metadata.pkl"

    # Dengue model artifacts
    dengue_model: Path = PROJECT_ROOT / "models" / "dengue" / "model.pkl"
    dengue_scaler: Path = PROJECT_ROOT / "models" / "dengue" / "scaler.pkl"
    dengue_features: Path = PROJECT_ROOT / "models" / "dengue" / "features.pkl"
    dengue_medians: Path = PROJECT_ROOT / "models" / "dengue" / "medians.pkl"
    dengue_label_encoders: Path = PROJECT_ROOT / "models" / "dengue" / "label_encoders.pkl"
    dengue_metadata: Path = PROJECT_ROOT / "models" / "dengue" / "metadata.pkl"

    # Metrics reports
    malaria_report: Path = PROJECT_ROOT / "reports" / "malaria_metrics.json"
    covid_report: Path = PROJECT_ROOT / "reports" / "covid_metrics.json"
    dengue_report: Path = PROJECT_ROOT / "reports" / "dengue_metrics.json"
    comparison_report: Path = PROJECT_ROOT / "reports" / "comparison.csv"

    # Database / auth / agent
    database_url: str | None = os.getenv("DATABASE_URL")
    jwt_secret: str = os.getenv("JWT_SECRET", "")
    jwt_algorithm: str = os.getenv("JWT_ALGORITHM", "HS256")
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "60"))
    db_pool_size: int = int(os.getenv("DB_POOL_SIZE", "3"))
    db_max_overflow: int = int(os.getenv("DB_MAX_OVERFLOW", "2"))

    malaria_prevalence: float = float(os.getenv("MALARIA_PREVALENCE", "0.12"))
    covid_prevalence: float = float(os.getenv("COVID_PREVALENCE", "0.02"))
    dengue_prevalence: float = float(os.getenv("DENGUE_PREVALENCE", "0.03"))

    rejection_threshold: float = float(os.getenv("REJECTION_THRESHOLD", "0.40"))
    ambiguity_gap: float = float(os.getenv("AMBIGUITY_GAP", "0.10"))

    availability_weight_power: float = float(os.getenv("AVAILABILITY_WEIGHT_POWER", "1.0"))

    deepseek_api_key: str | None = os.getenv("DEEPSEEK_API_KEY")
    deepseek_model: str = os.getenv("DEEPSEEK_MODEL", "deepseek-flash")
    deepseek_base_url: str = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

    cors_origins: tuple[str, ...] = tuple(
        origin.strip()
        for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
        if origin.strip()
    )

    # Diagnosis
    diagnosis_threshold: float = float(os.getenv("DIAGNOSIS_THRESHOLD", "0.6"))

    # Missing-value sentinels
    numeric_missing: float = -999.0
    binary_missing: int = -1
    categorical_missing: str = "Unknown"

    # Missingness augmentation
    missing_rate_min: float = 0.05
    missing_rate_max: float = 0.25

    # Confidence thresholds
    confidence_high_prob: float = 0.80
    confidence_high_coverage: float = 0.80
    confidence_medium_prob: float = 0.60
    confidence_medium_coverage: float = 0.50


    @property
    def deployment_prevalence(self) -> dict[str, float]:
        return {
            "malaria": self.malaria_prevalence,
            "covid": self.covid_prevalence,
            "dengue": self.dengue_prevalence,
        }

settings = Settings()
if not settings.jwt_secret or len(settings.jwt_secret) < 32:
    raise RuntimeError("JWT_SECRET must be set and contain at least 32 characters.")
